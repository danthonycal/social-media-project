'use strict';


// add comment on own post

// edit comment on own post

// delete comment on own post


// add comment on friend's post

// edit comment on friend's post

// delete comment on friend's post


// like comment

// unlike comment